$(document).ready(function () {
    // 5.SLIDER START

    $(".card__slider").slick();

    // 5.SLIDER END

    // 7.FIX SLICK + FANCYBOX START

    $(".slick-cloned a").removeAttr("data-fancybox");

    // 7.FIX SLICK + FANCYBOX END
});